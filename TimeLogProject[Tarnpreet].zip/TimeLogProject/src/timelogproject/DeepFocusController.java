/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package timelogproject;

import static com.sun.org.apache.xalan.internal.lib.ExsltDatetime.date;
import java.net.URL;
import java.sql.Connection;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

/**
 * FXML Controller class
 *
 * @author Tarn
 */
public class DeepFocusController implements Initializable {

    /**
     * Initializes the controller class.
     */
    
    
    private final String URL = "jdbc:sqlite:timelog.db";
    private Connection connection;
    
    
    @FXML
    private Label dateTime;
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        //Make connection:
        
        //Combo Box: Make a list of items that have been uploaded into the database:
        
        //Clock:
        initClock();}

private void initClock() {
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
    //get current date time with Date()
    //Date date;
    
    Date date = new Date();
    System.out.println(date.toString());
    
    //System.out.println(dateFormat.format(dateTime));
 
    //get current date time with Calendar()
    Calendar cal = Calendar.getInstance();
    System.out.println(dateFormat.format(cal.getTime()));
}


}
